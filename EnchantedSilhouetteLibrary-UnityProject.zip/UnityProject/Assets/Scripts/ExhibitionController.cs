using System;
using UnityEngine;

public sealed class ExhibitionController : MonoBehaviour
{
    public bool mousePractice,showSilhouette=true;
    public float controlSpan=.65f,soundLevel=.16f;
    readonly ShadowContact shadow=new ShadowContact();
    readonly MagicLibrary world=new MagicLibrary();
    readonly AnimalCompanions companions=new AnimalCompanions();
    readonly FieldHand[] hands=new FieldHand[2];
    readonly Vector2[] previous=new Vector2[2];
    readonly double[] seen={-100,-100};
    readonly float[] frameAt={-100,-100};
    Texture2D background,paintings,emptyPaintings,owl,fox,owlFlight,foxHop,butterfly,silhouette,glow;
    readonly Color32[] shadowPixels=new Color32[320*180];
    Camera view; Font font; AudioSource audioSource; AudioClip chime;
    string status="Kinect starting...";
    bool settings,mouseDown,capturing; float captureAt,lastMask=-100;
    Vector2 mouse; Rect viewport;
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void Bootstrap()
    {
        if(FindAnyObjectByType<ExhibitionController>()!=null)return;
        var go=new GameObject("The waking library");go.AddComponent<ExhibitionController>();go.AddComponent<ExhibitionKinectInput>();
    }
    void Awake()
    {
        Application.runInBackground=true;Application.targetFrameRate=60;
        view=Camera.main;if(view==null){view=new GameObject("Exhibition Camera").AddComponent<Camera>();view.tag="MainCamera";}
        view.clearFlags=CameraClearFlags.SolidColor;view.backgroundColor=Color.black;
        background=Resources.Load<Texture2D>("Magic/Library");paintings=Resources.Load<Texture2D>("Magic/Paintings");butterfly=Resources.Load<Texture2D>("Magic/Butterfly");
        emptyPaintings=Resources.Load<Texture2D>("Magic/EmptyPaintings");owl=Resources.Load<Texture2D>("Magic/Owl");fox=Resources.Load<Texture2D>("Magic/Fox");
        owlFlight=Resources.Load<Texture2D>("Magic/OwlFlight");foxHop=Resources.Load<Texture2D>("Magic/FoxHop");
        silhouette=new Texture2D(320,180,TextureFormat.RGBA32,false);silhouette.wrapMode=TextureWrapMode.Clamp;
        glow=new Texture2D(64,64,TextureFormat.RGBA32,false);
        var pixels=new Color[4096];for(int y=0;y<64;y++)for(int x=0;x<64;x++){float d=new Vector2((x-31.5f)/31.5f,(y-31.5f)/31.5f).magnitude;pixels[y*64+x]=new Color(1,1,1,Mathf.Pow(Mathf.Max(0,1-d),2));}glow.SetPixels(pixels);glow.Apply();
        font=Font.CreateDynamicFontFromOSFont(new[]{"Yu Gothic","Meiryo","Arial"},24);
        if(FindAnyObjectByType<AudioListener>()==null)view.gameObject.AddComponent<AudioListener>();
        audioSource=gameObject.AddComponent<AudioSource>();audioSource.spatialBlend=0;
        const int rate=22050;var samples=new float[rate*2];
        for(int i=0;i<samples.Length;i++){double t=(double)i/rate;samples[i]=(float)((Math.Sin(t*2*Math.PI*523.25)+Math.Sin(t*2*Math.PI*784)*.4+Math.Sin(t*2*Math.PI*1046.5)*.3)*Math.Exp(-t*3)*.25);}
        chime=AudioClip.Create("A painting awakens",samples.Length,1,rate,false);chime.SetData(samples,0);
    }
    public void SetStatus(string value){status=value;}
    public void SetFrame(byte[] pixels,int width,int height,GunInput left,GunInput right,byte[] mask)
    {
        if(mask!=null&&mask.Length==320*180*4)
        {
            shadow.SetMask(mask);lastMask=Time.unscaledTime;
            for(int y=0;y<180;y++)for(int x=0;x<320;x++)
            {
                int sx=319-x,src=(y*320+sx)*4;bool inside=mask[src+3]>100;
                shadowPixels[(179-y)*320+x]=new Color32(0,0,0,(byte)(inside?70:0));
            }
            silhouette.SetPixels32(shadowPixels);silhouette.Apply(false);
        }
        if(!mousePractice){Receive(0,left);Receive(1,right);}
    }
    void Receive(int i,GunInput hand)
    {
        if(!hand.Tracked){hands[i].Active=false;return;}
        var p=new Vector2(1-hand.AimX,hand.AimY);double dt=hand.Timestamp-seen[i];
        var v=dt>.01&&dt<.3?Vector2.ClampMagnitude((p-previous[i])/(float)dt,2):Vector2.zero;
        hands[i]=new FieldHand{Active=p.x>=0&&p.x<=1&&p.y>=0&&p.y<=1,Open=hand.Pose,X=p.x,Y=p.y,VX=v.x,VY=v.y};
        previous[i]=p;seen[i]=hand.Timestamp;frameAt[i]=Time.unscaledTime;
    }
    void Update()
    {
        float w=Screen.width,h=Screen.height,aspect=16f/9;
        viewport=w/h>aspect?new Rect((w-h*aspect)/2,0,h*aspect,h):new Rect(0,(h-w/aspect)/2,w,w/aspect);
        for(int i=0;i<2;i++)if(Time.unscaledTime-frameAt[i]>.3f)hands[i].Active=false;
        if(mousePractice)
        {
            var p=new Vector2((mouse.x-viewport.x)/viewport.width,(mouse.y-viewport.y)/viewport.height);
            var v=Vector2.ClampMagnitude((p-previous[0])/Mathf.Max(.01f,Time.unscaledDeltaTime),2);
            hands[0]=new FieldHand{Active=mouseDown,Open=true,X=p.x,Y=p.y,VX=v.x,VY=v.y};previous[0]=p;hands[1].Active=false;
        }
        world.Step(Time.unscaledDeltaTime,shadow,hands[0],hands[1],Time.unscaledTime-lastMask<.35f,mousePractice);
        companions.Step(Time.unscaledDeltaTime,world.Time,world,hands[0],hands[1]);
        if(world.NewAwakenings>0){audioSource.pitch=.9f+world.Awakened*.12f;audioSource.PlayOneShot(chime,soundLevel);}
        if(capturing&&Time.unscaledTime>=captureAt){GetComponent<ExhibitionKinectInput>()?.CaptureBackground();capturing=false;ResetWorld();}
    }
    Rect R(float x,float y,float w,float h)=>new Rect(viewport.x+x*viewport.width,viewport.y+y*viewport.height,w*viewport.width,h*viewport.height);
    void Fill(Rect r,Color c){GUI.color=c;GUI.DrawTexture(r,Texture2D.whiteTexture);GUI.color=Color.white;}
    void Halo(float x,float y,float size,Color c){GUI.color=c;GUI.DrawTexture(R(x-size/2,y-size*.8889f,size,size*1.77778f),glow);GUI.color=Color.white;}
    GUIStyle Label(int size,Color c,TextAnchor alignment=TextAnchor.MiddleLeft)
    {var s=new GUIStyle(GUI.skin.label){font=font,fontSize=size,alignment=alignment,wordWrap=true};s.normal.textColor=c;return s;}
    void OnGUI()
    {
        mouse=Event.current.mousePosition;
        if(Event.current.type==EventType.MouseDown&&Event.current.button==0&&!settings)mouseDown=true;
        if(Event.current.type==EventType.MouseUp)mouseDown=false;
        if(Event.current.type==EventType.KeyDown){if(Event.current.keyCode==KeyCode.F1){settings=!settings;mouseDown=false;Event.current.Use();}else if(Event.current.keyCode==KeyCode.R){ResetWorld();Event.current.Use();}}
        if(background!=null)GUI.DrawTexture(viewport,background,ScaleMode.StretchToFill);else Fill(viewport,new Color(.025f,.045f,.08f));
        float t=world.Time;
        for(int i=0;i<3;i++)
        {
            var p=world.Pictures[i];float bob=Mathf.Sin(t*3+i)*.004f*p.Energy;
            var frameMatrix=GUI.matrix;
            GUIUtility.RotateAroundPivot(p.Sway*90,R(p.X,p.Y-.17f,0,0).position);
            Halo(p.X,p.Y,.3f,new Color(1,.57f,.15f,p.Glow*.65f));
            Rect frame=R(p.X-.106f,p.Y-.172f+bob,.212f,.344f);
            Fill(new Rect(frame.x+7,frame.y+9,frame.width,frame.height),new Color(0,0,0,.6f));
            Fill(frame,new Color(.29f,.16f,.055f));frame=new Rect(frame.x+4,frame.y+4,frame.width-8,frame.height-8);Fill(frame,new Color(.83f+p.Glow*.17f,.58f+p.Glow*.18f,.22f));
            Rect art=R(p.X-.096f,p.Y-.154f+bob,.192f,.308f);
            if(paintings!=null)
            {
                GUI.color=Color.white;
                var animal=i==1?null:companions.Animals[i==0?0:1];
                bool escaped=animal!=null&&animal.Active&&emptyPaintings!=null;
                // Distort the artwork inside its frame: the palm pushes a wave through the painted world.
                const int strips=48;
                for(int row=0;row<strips;row++)
                {
                    float y=(row+.5f)/strips;
                    float proximity=Mathf.Exp(-Mathf.Pow((p.Y-.154f+y*.308f-p.TouchY)*7,2));
                    float wave=Mathf.Sin(y*13-t*5)*.014f*p.Energy*proximity;
                    float pan=Mathf.Clamp((p.TouchX-p.X)*.18f,-.018f,.018f)*p.Energy;
                    var slice=new Rect(art.x,art.y+row*art.height/strips,art.width,art.height/strips+.6f);
                    var uv=new Rect((i+.035f+pan+wave)/3, .035f+(1-(row+1f)/strips)*.93f,.93f/3,.93f/strips);
                    GUI.color=Color.white;
                    GUI.DrawTextureWithTexCoords(slice,escaped?emptyPaintings:paintings,uv);
                    float painted=escaped?(animal.Returning?Mathf.Clamp01((animal.ReturnAge-1.1f)/.5f):Mathf.Clamp01(1-animal.Age/.35f)):0;
                    if(painted>0){GUI.color=new Color(1,1,1,painted);GUI.DrawTextureWithTexCoords(slice,paintings,uv);}
                }
                GUI.color=Color.white;
            }
            if(p.Energy>.01f)for(int k=0;k<5;k++){float a=t*1.4f+k*1.256f+i;Halo(p.X+Mathf.Sin(a)*.08f,p.Y+Mathf.Cos(a)*.13f,.015f,new Color(1,.86f,.35f,p.Energy*.9f));}
            GUI.matrix=frameMatrix;
        }
        if(showSilhouette&&Time.unscaledTime-lastMask<.35f)GUI.DrawTexture(viewport,silhouette);
        DrawAnimals();
        for(int i=0;i<2;i++)if(hands[i].Active)
        {
            var h=hands[i];Color c=h.Open?new Color(1,.85f,.45f,.7f):new Color(.4f,.75f,.9f,.35f);
            Halo(h.X,h.Y,.065f,c);
        }
        // Dust begins to fill the room only after the visitor has awakened a painting.
        for(int k=0;k<world.Awakened*16;k++){float x=Mathf.Repeat(k*.618034f+Mathf.Sin(t*.12f+k)*.025f,1);float y=Mathf.Repeat(k*.3819f-t*.008f,1);Halo(x,y,.009f,new Color(1,.75f,.3f,.35f));}
        foreach(var b in world.Butterflies)if(b.Age>=0)
        {
            float wing=.25f+.75f*Mathf.Abs(Mathf.Sin(t*(b.Hand>=0?7:12)+b.Phase));
            Color c=Color.Lerp(new Color(.28f,.9f,1),new Color(1,.7f,.25f),(b.Home%2));
            Halo(b.X,b.Y,.055f,new Color(c.r,c.g,c.b,.8f*b.Alpha));
            var pos=R(b.X,b.Y,0,0).position;
            var old=GUI.matrix;GUIUtility.RotateAroundPivot(Mathf.Sin(t+b.Phase)*20,pos);
            float unit=viewport.height;GUI.color=new Color(1,1,1,b.Alpha);
            if(butterfly!=null)GUI.DrawTexture(new Rect(pos.x-.024f*unit*wing,pos.y-.024f*unit,.048f*unit*wing,.048f*unit),butterfly);
            GUI.color=Color.white;GUI.matrix=old;
        }
        float u=Screen.height/1000f;
        GUI.Label(R(.04f,.035f,.7f,.05f),"めざめる絵の図書館",Label(Mathf.RoundToInt(25*u),new Color(1,.88f,.64f)));
        bool animalOutside=companions.Animals[0].Active||companions.Animals[1].Active;
        string hint=animalOutside?"手のひらで道を描こう。絵から出た動物が、あとをついてくる。":"動物の絵に、手のひらで触れてみよう。";
        GUI.Label(R(.1f,.91f,.8f,.055f),hint,Label(Mathf.RoundToInt(22*u),new Color(1,.93f,.78f),TextAnchor.MiddleCenter));
        if(capturing)GUI.Label(R(.1f,.35f,.8f,.2f),"背景を記録します。カメラの外へ移動してください\n"+Mathf.CeilToInt(captureAt-Time.unscaledTime),Label(Mathf.RoundToInt(30*u),Color.white,TextAnchor.MiddleCenter));
        if(settings)Settings(Mathf.Max(.7f,u));
    }
    void Settings(float u)
    {
        Rect r=new Rect(Screen.width-455*u,25*u,425*u,570*u);Fill(r,new Color(.02f,.035f,.07f,.97f));float x=r.x+24*u,y=r.y+20*u,w=r.width-48*u;
        GUI.Label(new Rect(x,y,w,35*u),"展示設定 / F1で閉じる",Label((int)(20*u),Color.white));y+=45*u;
        GUI.Label(new Rect(x,y,w,65*u),status,Label((int)(14*u),new Color(.6f,.8f,.95f)));y+=70*u;
        mousePractice=GUI.Toggle(new Rect(x,y,w,30*u),mousePractice," マウスで確認（押しながら絵に触れる）");y+=35*u;
        showSilhouette=GUI.Toggle(new Rect(x,y,w,30*u),showSilhouette," 自分のシルエットを表示");y+=40*u;
        GUI.Label(new Rect(x,y,w,45*u),"開いた手のひらで絵に触れると目覚めます。\n手を止めると蝶が集まります。",Label((int)(15*u),Color.white));y+=60*u;
        GUI.Label(new Rect(x,y,w,25*u),"音量",Label((int)(16*u),Color.white));y+=30*u;soundLevel=GUI.HorizontalSlider(new Rect(x,y,w,20*u),soundLevel,0,.35f);y+=35*u;
        var sensor=GetComponent<ExhibitionKinectInput>();if(sensor!=null){GUI.Label(new Rect(x,y,w,25*u),"シルエット距離 "+(sensor.silhouetteMaxDepth/1000f).ToString("F1")+"m",Label((int)(16*u),Color.white));y+=30*u;sensor.silhouetteMaxDepth=Mathf.RoundToInt(GUI.HorizontalSlider(new Rect(x,y,w,20*u),sensor.silhouetteMaxDepth,1500,5000));y+=35*u;if(GUI.Button(new Rect(x,y,w,35*u),"背景を登録する（5秒後）")){capturing=true;captureAt=Time.unscaledTime+5;settings=false;}y+=45*u;}
        if(GUI.Button(new Rect(x,y,w,35*u),"動物を絵に戻す（R）"))ResetWorld();
    }
    void ResetWorld(){world.Reset();companions.Reset();}
    void DrawAnimals()
    {
        for(int hand=0;hand<2;hand++)
        {
            bool following=false;foreach(var a in companions.Animals)if(a.Active&&!a.Returning&&a.Hand==hand)following=true;
            if(!following)continue;
            var trail=companions.Trails[hand];
            for(int k=1;k<trail.Count;k++)
            {
                var p=trail[k-1];var q=trail[k];
                float alpha=Mathf.Clamp01(1-(world.Time-q.Time)/4)*.55f;
                Vector2 start=R(p.X,p.Y,0,0).position,end=R(q.X,q.Y,0,0).position;
                var delta=end-start;var matrix=GUI.matrix;
                GUIUtility.RotateAroundPivot(Mathf.Atan2(delta.y,delta.x)*Mathf.Rad2Deg,start);
                Fill(new Rect(start.x,start.y-1,delta.magnitude,2),new Color(1,.8f,.32f,alpha));GUI.matrix=matrix;
            }
        }
        for(int i=0;i<2;i++)
        {
            var a=companions.Animals[i];var sheet=i==0?owlFlight:foxHop;var texture=sheet!=null?sheet:(i==0?owl:fox);if(!a.Active||texture==null)continue;
            float emerge=Mathf.SmoothStep(0,1,Mathf.Clamp01(a.Age/.65f));
            float motion=Mathf.Clamp01(a.Speed*5);
            float cycle=Mathf.Repeat(a.Age*(i==0?2:1.8f),1);
            float bob=i==0?Mathf.Sin(a.Age*8)*.006f:Mathf.Sin(cycle*Mathf.PI)*.025f*motion;
            float size=(i==0?.13f:.15f)*Mathf.Lerp(.75f,1,emerge);
            float height=size*1.77778f*texture.height/(sheet!=null?texture.width/4f:texture.width);
            Halo(a.X,a.Y,.19f,new Color(1,.75f,.3f,.5f*(1-emerge)));
            Rect rect=R(a.X-size/2,a.Y-height/2-bob,size,height);
            var matrix=GUI.matrix;
            GUIUtility.RotateAroundPivot(Mathf.Sin(a.Age*7)*(i==0?3:5)*motion,rect.center);
            float returning=a.Returning?1-Mathf.Clamp01((a.ReturnAge-1.1f)/.5f):1;
            GUI.color=new Color(1,1,1,Mathf.Clamp01(a.Age/.2f)*returning);
            int frame=sheet!=null?(i==1&&motion<.05f?0:Mathf.Min(3,(int)(cycle*4))):0;
            float cell=sheet!=null?.25f:1;
            GUI.DrawTextureWithTexCoords(rect,texture,a.FacingRight?new Rect(frame*cell,0,cell,1):new Rect((frame+1)*cell,0,-cell,1));
            GUI.color=Color.white;GUI.matrix=matrix;
        }
    }
    void OnApplicationFocus(bool focused){if(!focused){mouseDown=false;hands[0].Active=hands[1].Active=false;}}
    void OnDestroy(){if(silhouette!=null)Destroy(silhouette);if(glow!=null)Destroy(glow);if(font!=null)Destroy(font);if(chime!=null)Destroy(chime);}
}
