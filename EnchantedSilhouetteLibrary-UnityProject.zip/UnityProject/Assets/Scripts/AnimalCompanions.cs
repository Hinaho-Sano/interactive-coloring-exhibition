using System;
using System.Collections.Generic;

// Animals consume the traced route in order, rather than cutting straight to the palm.
public sealed class AnimalCompanions
{
    public struct Point { public float X,Y,Time; public Point(float x,float y,float t){X=x;Y=y;Time=t;} }
    public sealed class Animal
    {
        public bool Active,FacingRight=true,Returning,WaitForRelease;
        public int Hand,Home;
        public float X,Y,Age,Speed,Missing,SampleAt=-100,LastX,LastY;
        public float ReturnAge,ReturnX,ReturnY;
        public readonly List<Point> Route=new List<Point>();
    }
    public readonly Animal[] Animals={new Animal{Home=0},new Animal{Home=2}};
    public readonly List<Point>[] Trails={new List<Point>(),new List<Point>()};
    readonly float[] lastSeen={-100,-100};
    public void Reset()
    {
        foreach(var a in Animals){a.Active=a.Returning=a.WaitForRelease=false;a.Route.Clear();a.Age=a.Speed=a.Missing=a.ReturnAge=0;a.SampleAt=-100;}
        foreach(var trail in Trails)trail.Clear();lastSeen[0]=lastSeen[1]=-100;
    }
    static float Distance(float x,float y,float x2,float y2){float dx=(x-x2)*16f/9,dy=y-y2;return (float)Math.Sqrt(dx*dx+dy*dy);}
    public void Step(float dt,float time,MagicLibrary library,FieldHand left,FieldHand right)
    {
        if(float.IsNaN(dt)||float.IsInfinity(dt)||dt<=0)return;
        dt=Math.Min(.05f,dt);var hands=new[]{left,right};
        for(int i=0;i<2;i++)
        {
            var h=hands[i];var trail=Trails[i];
            if(h.Active&&h.Open)
            {
                if(time-lastSeen[i]>.35f)trail.Clear();
                if(trail.Count==0||Distance(h.X,h.Y,trail[trail.Count-1].X,trail[trail.Count-1].Y)>.008f)
                {
                    if(trail.Count>0&&Distance(h.X,h.Y,trail[trail.Count-1].X,trail[trail.Count-1].Y)>.35f)trail.Clear();
                    trail.Add(new Point(h.X,h.Y,time));if(trail.Count>180)trail.RemoveAt(0);
                }
                lastSeen[i]=time;
            }
            while(trail.Count>0&&time-trail[0].Time>4)trail.RemoveAt(0);
        }
        foreach(var a in Animals)
        {
            var picture=library.Pictures[a.Home];
            if(a.WaitForRelease)
            {
                picture.AwakeTime=-1;picture.Contact=0;
                if(!picture.Touching)a.WaitForRelease=false;
            }
            if(!a.Active&&!a.WaitForRelease&&picture.Awake)
            {
                a.Active=true;a.Hand=picture.Hand;a.X=picture.X;a.Y=picture.Y;
                a.Age=a.Missing=a.ReturnAge=0;a.Returning=false;a.SampleAt=-100;a.Route.Clear();
            }
            if(!a.Active)continue;
            a.Age+=dt;
            if(!a.Returning&&(a.Age>=10||a.Missing>=3))
            {
                a.Returning=true;a.ReturnAge=0;a.ReturnX=a.X;a.ReturnY=a.Y;a.Route.Clear();
            }
            if(a.Returning)
            {
                a.ReturnAge+=dt;
                float f=Math.Min(1,a.ReturnAge/1.6f);f=f*f*(3-2*f);
                float px=a.X,py=a.Y;
                a.X=a.ReturnX+(picture.X-a.ReturnX)*f;a.Y=a.ReturnY+(picture.Y-a.ReturnY)*f;
                a.Speed=Distance(px,py,a.X,a.Y)/dt;
                if(Math.Abs(a.X-px)>.0001f)a.FacingRight=a.X>px;
                if(a.ReturnAge>=1.6f)
                {
                    a.Active=a.Returning=false;a.WaitForRelease=true;a.Speed=0;
                    picture.AwakeTime=-1;picture.Contact=picture.Energy=picture.Glow=0;
                    Trails[a.Hand].Clear();
                }
                continue;
            }
            var h=hands[a.Hand];
            if(!h.Active||!h.Open)
            {
                a.Missing+=dt;
                if(a.Missing>1)
                {
                    int other=1-a.Hand;
                    if(hands[other].Active&&hands[other].Open){a.Hand=other;h=hands[other];a.Route.Clear();a.SampleAt=-100;a.Missing=0;}
                }
            }
            else a.Missing=0;
            if(h.Active&&h.Open)
            {
                // Never bridge tracking gaps or a discontinuous hand reassignment.
                if(time-a.SampleAt>.35f||Distance(h.X,h.Y,a.LastX,a.LastY)>.35f){a.Route.Clear();a.SampleAt=-100;}
                if(a.SampleAt<0||Distance(h.X,h.Y,a.LastX,a.LastY)>.008f)
                {
                    a.Route.Add(new Point(h.X,h.Y,time));a.LastX=h.X;a.LastY=h.Y;
                    if(a.Route.Count>180)a.Route.RemoveAt(0);
                }
                a.SampleAt=time;
            }
            else if(a.Missing>.35f)a.Route.Clear();
            float beforeX=a.X,beforeY=a.Y;
            float budget=dt*(a.Home==0?.52f:.44f);
            while(a.Route.Count>0&&budget>0&&a.Age>.25f)
            {
                var p=a.Route[0];if(time-p.Time<.22f)break;
                float distance=Distance(a.X,a.Y,p.X,p.Y);
                if(distance<=budget){a.X=p.X;a.Y=p.Y;budget-=distance;a.Route.RemoveAt(0);}
                else{float f=budget/distance;a.X+=(p.X-a.X)*f;a.Y+=(p.Y-a.Y)*f;budget=0;}
            }
            a.Speed=Distance(beforeX,beforeY,a.X,a.Y)/dt;
            if(Math.Abs(a.X-beforeX)>.0001f)a.FacingRight=a.X>beforeX;
        }
    }
}
