using System;

// Time-based interaction model; only an open palm can wake a painting.
public sealed class MagicLibrary
{
    public sealed class Painting
    {
        public float X,Y,Contact,AwakeTime=-1,Glow;
        public float TouchX,TouchY,Energy,Sway,SwayVelocity,LastRelease=-100;
        public bool Touching,Released;
        public int Hand;
        public bool Awake=>AwakeTime>=0;
    }
    public sealed class Butterfly
    {
        public float X,Y,Phase,Age;
        public bool Returning;
        public float ReturnAge,ReturnX,ReturnY,Alpha=1;
        public int Hand=-1,Home;
    }
    public readonly Painting[] Pictures={new Painting{X=.23f,Y=.43f},new Painting{X=.5f,Y=.36f},new Painting{X=.77f,Y=.43f}};
    public readonly System.Collections.Generic.List<Butterfly> Butterflies=new System.Collections.Generic.List<Butterfly>();
    public int Awakened { get { int n=0; foreach(var p in Pictures) if(p.Awake)n++; return n; } }
    public int NewAwakenings;
    public float Time;
    public void Reset() { foreach(var p in Pictures){p.Contact=p.Glow=p.Energy=p.Sway=p.SwayVelocity=0;p.AwakeTime=-1;p.LastRelease=-100;p.Touching=p.Released=false;} Butterflies.Clear();Time=0; }
    public static bool Calm(FieldHand h)=>h.Active&&h.Open&&h.Y<.85f&&h.VX*h.VX+h.VY*h.VY<.035f;
    public void Step(float dt,ShadowContact shadow,FieldHand left,FieldHand right,bool live,bool practice)
    {
        NewAwakenings=0;
        if(float.IsNaN(dt)||float.IsInfinity(dt)||dt<=0)return;
        dt=Math.Min(dt,.05f);Time+=dt;
        var hands=new[]{left,right};
        for(int i=0;i<Pictures.Length;i++)
        {
            var p=Pictures[i]; bool overlap=false;
            FieldHand touching=default;
            for(int j=0;j<2;j++){var h=hands[j];if(h.Active&&h.Open&&Math.Abs(h.X-p.X)<.096f&&Math.Abs(h.Y-p.Y)<.154f&&(practice||live&&shadow.Touches(h.X,h.Y))){overlap=true;touching=h;p.Hand=j;}}
            if(overlap)
            {
                p.TouchX=touching.X;p.TouchY=touching.Y;
                p.Energy=Math.Min(1,p.Energy+dt*5);
                p.SwayVelocity+=((touching.X-p.X)*70+touching.VX*5)*dt;
            }
            else {p.Energy=Math.Max(0,p.Energy-dt*.4f);p.Released=false;}
            p.Touching=overlap;
            p.SwayVelocity+=(-p.Sway*22-p.SwayVelocity*5)*dt;
            p.Sway+=p.SwayVelocity*dt;
            p.Sway=Math.Max(-.055f,Math.Min(.055f,p.Sway));
            p.Contact=Math.Max(0,Math.Min(.55f,p.Contact+(overlap?dt:-dt*2)));
            p.Glow+=( (overlap?1:0)-p.Glow)*dt*4;
            if(!p.Awake&&p.Contact>=.5f)
            {
                p.AwakeTime=Time;NewAwakenings++;
            }
            if(overlap&&p.Contact>=.5f&&!p.Released&&Time-p.LastRelease>1.5f)
            {
                p.Released=true;p.LastRelease=Time;
                int count=p.AwakeTime==Time?7:3;
                for(int k=0;k<count&&Butterflies.Count<36;k++)Butterflies.Add(new Butterfly{X=p.TouchX,Y=p.TouchY,Home=i,Phase=k*2.399f+i+Time,Age=-k*.12f});
            }
        }
        foreach(var b in Butterflies)
        {
            b.Age+=dt;if(b.Age<0)continue;
            if(!b.Returning&&b.Age>=10){b.Returning=true;b.Hand=-1;b.ReturnX=b.X;b.ReturnY=b.Y;}
            if(b.Returning)
            {
                b.ReturnAge+=dt;float f=Math.Min(1,b.ReturnAge/1.6f);f=f*f*(3-2*f);
                var home=Pictures[b.Home];b.X=b.ReturnX+(home.X-b.ReturnX)*f;b.Y=b.ReturnY+(home.Y-b.ReturnY)*f;
                b.Alpha=Math.Max(0,1-Math.Max(0,(b.ReturnAge-1.1f)/.5f));
                continue;
            }
            int hand=-1;float best=10;
            for(int j=0;j<2;j++)if(Calm(hands[j]))
            { float dx=hands[j].X-b.X,dy=hands[j].Y-b.Y;float d=dx*dx+dy*dy;if(d<best){best=d;hand=j;} }
            b.Hand=hand;
            float tx,ty;
            if(hand>=0)
            {
                var h=hands[hand];float radius=best<.002f?.007f:.025f;
                tx=h.X+(float)Math.Sin(Time*1.2+b.Phase)*radius;
                ty=h.Y-.018f+(float)Math.Cos(Time+b.Phase)*radius*.6f;
            }
            else
            {
                var home=Pictures[b.Home];
                tx=home.X+(float)Math.Sin(Time*.37+b.Phase)*.16f;
                ty=home.Y+(float)Math.Cos(Time*.51+b.Phase)*.14f;
                foreach(var h in hands)if(h.Active)
                {float dx=b.X-h.X,dy=b.Y-h.Y,d=dx*dx+dy*dy;if(d<.02f&&h.VX*h.VX+h.VY*h.VY>.3f){tx=b.X+dx*2+h.VX*.15f;ty=b.Y+dy*2+h.VY*.15f;}}
            }
            float speed=hand>=0?2:1.1f;
            b.X+=(tx-b.X)*Math.Min(1,dt*speed);b.Y+=(ty-b.Y)*Math.Min(1,dt*speed);
        }
        Butterflies.RemoveAll(b=>b.Returning&&b.ReturnAge>=1.6f);
    }
}
